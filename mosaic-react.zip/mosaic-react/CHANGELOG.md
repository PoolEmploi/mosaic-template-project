# CHANGELOG.md

## [4.3.1] - 2022-07-21

- Fix issue with mobile menu not expanding

## [4.3.0] - 2022-07-15

- Replace Sass with CSS files

## [4.2.0] - 2022-07-11

- Update dependencies
- Update React to v18

## [4.1.0] - 2022-07-11

- Several minor changes

## [4.0.0] - 2022-03-03

- v4 Release

## [3.10.0] - 2022-02-23

- Add Forum pages

## [3.9.0] - 2022-02-19

- Add more pages

## [3.8.0] - 2022-02-09

- Add Meetups pages

## [3.5.0] - 2022-02-08

- Add a new cart page

## [3.4.1] - 2022-02-05

- Minor change

## [3.4.0] - 2022-02-04

- Add Fintech page

## [3.3.0] - 2022-01-25

- Replace CRA (Create React App) with Vite
- Remove Craco
- Update dependencies

## [3.2.0] - 2022-01-13

- Minor changes

## [3.1.0] - 2021-12-13

- Update Tailwind 3
- Several improvements

## [3.0.0] - 2021-10-20

Add more pages
Update dependencies and remove some

## [2.2.0] - 2021-09-09

Add Cart, Cart 2 and Pay pages

## [2.1.0] - 2021-09-06

Add Invoices page

## [2.0.2] - 2021-08-30

Improve colors in settings sidebar and fix dashboard icon

## [2.0.1] - 2021-08-30

Sidebar fix

## [2.0.0] - 2021-08-30

Add more pages and components

## [1.1.0] - 2021-05-06

Several improvements

## [1.0.0] - 2021-04-20

First release