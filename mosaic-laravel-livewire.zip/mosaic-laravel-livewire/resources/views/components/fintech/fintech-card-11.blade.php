<div class="flex flex-col col-span-full sm:col-span-6 xl:col-span-3 bg-white shadow-lg rounded-sm border border-slate-200">
    <div class="px-5 pt-5">
        <header>
            <h3 class="text-sm font-semibold text-slate-500 uppercase mb-1"><span class="text-slate-800">Amzn</span> - Amazon Inc.</h3>
            <div class="text-2xl font-bold text-slate-800 mb-1">$3,400.35</div>
            <div class="text-sm"><span class="font-medium text-emerald-500">+$142 (3,7%)</span> - Today</div>
        </header>
    </div>
    <div class="grow">
        <canvas id="fintech-card-11" width="286" height="98"></canvas>
    </div>
</div>
