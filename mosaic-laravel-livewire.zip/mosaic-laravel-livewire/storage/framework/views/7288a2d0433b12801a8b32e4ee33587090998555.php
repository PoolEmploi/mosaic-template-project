<button <?php echo e($attributes->merge(['type' => 'submit', 'class' => 'btn bg-indigo-500 hover:bg-indigo-600 text-white whitespace-nowrap'])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH /Users/pasqualevitiello/My Folder/Job/Projects/Gits/cruip-templates-v2/templates/mosaic-laravel-livewire/resources/views/vendor/jetstream/components/button.blade.php ENDPATH**/ ?>